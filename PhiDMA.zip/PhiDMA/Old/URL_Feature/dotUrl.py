st = "guni.khan.sonowal."
count = 0
for line in st:
    if line == ".":
        count = count + 1
print count        
