st = "guni@khan-sonowal."
if "@" in st or "-" in st:
    print "suspicious"
else:
    print "not suspicious"      
