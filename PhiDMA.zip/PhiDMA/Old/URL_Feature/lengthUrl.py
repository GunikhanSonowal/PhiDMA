l = len("gunikhan osnowal")
print l
