from datetime import datetime
import socket
from tld import get_tld
from ipwhois import IPWhois
from pprint import pprint
urls = "http://google.co.in/"
try:
    domain = get_tld(urls)
    ipadress = socket.gethostbyname(domain)
    obj = IPWhois(ipadress)
    results = obj.lookup_rdap(depth=1)
    st = results['asn_date']
    b_date = datetime.strptime(st, '%Y-%m-%d')
    print "Age : %d" % ((datetime.today() - b_date).days/365)
except Exception,e:
    print 1    

