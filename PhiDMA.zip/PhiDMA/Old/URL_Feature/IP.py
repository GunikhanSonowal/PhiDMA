from urlparse import urlparse
import tldextract
import re
def validate_ip(s):
    a = s.split('.')
    if len(a) != 4:
        return False
    for x in a:
        if not x.isdigit():
            return False
        i = int(x)
        if i < 0 or i > 255:
            return False
    return True
ext = tldextract.extract('http://google.com123/~csaczcom/')
ext.domain
st = ext.domain
print "domain",st
IpValide = validate_ip(st)
print IpValide
    
