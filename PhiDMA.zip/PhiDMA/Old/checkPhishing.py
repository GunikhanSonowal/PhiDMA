import numpy
import codecs

def standard1(b):
    infile2 = codecs.open('final_result.txt', encoding='utf-8')
    sd1 = sd2 = sd3 = 0
    for line in infile2:
        st =  line.split()

        b.append(st[0])
        print b
        b = map(int, b)  
        sd1 = numpy.std(b)
        return sd1
        break        
def standard2(b):
    infile2 = codecs.open('final_result.txt', encoding='utf-8')
    sd1 = sd2 = sd3 = 0
    for line in infile2:
        st =  line.split()

        b.append(st[3])
        print b
        b = map(int, b)  
        sd1 = numpy.std(b)
        return sd1
        break 
def standard3():
    return 2
def main():
    a  = []
    b = []
    infile1 = codecs.open('final_result.txt', encoding='utf-8')
    for line in infile1:
        line1 = line.split()
    a.append(line1[0])
    b.append(line1[2])
    result = standard1(a)
    result1 = standard2(b)
    print result
    main()    
        
