from lcs1 import lcsMain
from editDistance import editDistance
inlist = open("totallink.txt", "r") # open the total link 
stringmatch = open("stringmatch.txt", "w")

def stringMatch(line):
    try:
        temp = 0
        print "string matchin start"
        for row in inlist:
            print "lcs result", lcsMain(row, line)
            print "edit distance", editDistance(row, line)
            if  lcsMain(row, line) >=64 and editDistance(row, line) >= 85: # check the link with url
                print "pass", row
                stringmatch.write(row)
                temp = 1
        stringmatch.close()  
    except Exception, e:
        print e 
    if temp == 1:
        return True
    else:
        return False    
    
        
