'''
import re
d = {}
fp = open("main_result.txt", "r")
line ='1 Errors 1 Likely Problems 129 Potential Problem'
line1 =  '1 Errors 2 Potential Problem'
checkline =  re.findall('\d+|\D+', line)

'''
import re
from itertools import islice
s= "1 Likely Problems 129 Potential Problems"

cstring=  "".join(s.split())

result = re.findall('\d+|\D+', s) # string start with number
result = [item.strip() for item in result]
result.reverse() # string with string
line = {}
def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())

line = dict(list(chunk(result, 2)))

print line['Potential Problems']
print line['Likely Problems']
