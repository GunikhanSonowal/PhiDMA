#Title : Phishign Detection Tool
#Developer : Gunikhan Sonowal

import sys
from whitelist import list # whitelist matching file
from urlFilter import url_feature # url feature extract file
from urlMatching import urlMatch # google, tf file
from StringMatch import stringMatch # url matching 
from final_result import accessibility # accessibility checking
from urlAcessibility
whitelist = open("whitelist.txt", "a+")
infile = open("phishingfile.txt","r")
for line in infile:
    url= url_feature(line)
    if url >= 2:
        print "phising site"
        sys.exit(1)
    else:
        print "*****URL FILTER PASS*****"+line+"\n"
        print "Whitelist check"
        checkList = list(line) 
        if checkList == 1:
            print "Legitimate site"
            sys.exit(1)
        
        else:
        
            print "Lexical Features checking........"
            urlMatch(line)
            ob = stringMatch(line)
            if ob == False:
                print "Fail string match"
            else:
                urlAccessibility.accessibility(line)
                accessibility()       
            
                
