import numpy
b = []
for line in range(2):
    a = raw_input("number input")
    b.append(a)
    
b = map(int, b)  
print numpy.std(b)
