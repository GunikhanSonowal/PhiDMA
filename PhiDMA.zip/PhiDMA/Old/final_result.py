import requests
from bs4 import BeautifulSoup
import re
def accessibility():
    try:
        print "\n accessibility checking start"
        fp=open('stringmatch.txt','r')
        urls = fp.read().split('\n')[:-1]
        def extract_result(html):
	        soup = BeautifulSoup(html,"lxml")
	        result = soup.find('span', {'style': 'color:red'}).get_text()
	        return result
        base_url= "http://achecker.ca/checkacc.php?"
        ff=open('guni.txt','w',)
        final = open("final_result.txt", "w")
        for url in urls:

	        payload={"uri":url,"id":"ca44c777a5bb9383f652f734f813320baea54aa2","guide":"WCAG2-AA","output":"html","offset" : 0}
	        r= requests.get(base_url, params=payload.items())
	        print r.status_code
	        if r.status_code == requests.codes.ok:
		        output= ''.join(e for e in url if e.isalnum())
		        #print output+'.html',"Result:",extract_result(r.text)
		        #result_line= str(url) +" "+ "Result:" + extract_result(r.text).encode('iso-8859-1') +'\n'
		        #ff.write(result_line)
		        #st = extract_result(r.text).encode('iso-8859-1')
		        final.write(extract_result(r.text).encode('utf-8')+"\n")
		        print extract_result(r.text)
	        else:
		        print "No data",url,r.status_code
	        #fb=open(output+".html",'w')
	        #fb.write(r.text)
	        fb.close()
        ff.close()
    except Exception, e:
        print "PHishing site:", e
        
def main():
    accessibility()
if __name__ == "__main__": main()                       
