import urllib2
url = "http://www.google.com"
web = open("file1.html", "w")
response = urllib2.urlopen(url)
html = response.read()
web.write("url:"+url+"\n")
web.write(html)
