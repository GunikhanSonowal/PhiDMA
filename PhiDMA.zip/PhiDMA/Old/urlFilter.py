from urlparse import urlparse
import tldextract
import sys
from datetime import datetime
import socket
from tld import get_tld
from ipwhois import IPWhois
from pprint import pprint

# Domain age
def domain_age(url):
    try:
        domain = get_tld(url)
        ipadress = socket.gethostbyname(domain)
        obj = IPWhois(ipadress)
        results = obj.lookup_rdap(depth=1)
        st = results['asn_date']
        b_date = datetime.strptime(st, '%Y-%m-%d')
        #print "Age : %d" % ((datetime.today() - b_date).days/365)
        if (datetime.today() - b_date).days/365 > 1:
            print "age is ok"
            return 0
        else:
            print "age is not ok"
            return 1    
    except Exception,e:
        print "age is undefine"
        return 0    
        
# Length of the url        
def length_url(url):
    l = len(url)
    if l > 53:
        print "length not ok"
        return 1
    else:
        print "length is ok"
        return 0    
# Domain contain IP    
def ipcheck(url):
    ext = tldextract.extract(url)
    ext.domain
    st = ext.domain
    if st.isalpha() == True:
        print "ip is ok"
        return 0
    else:
        
        print "ip is not ok"
        return 1    
# Number of dots
def dotUrl(url):
    count = 0
    st = url
    for line in st:
        if line == ".":
            count = count + 1
    if count >= 3:
        print "dots is no ok"
        return 1
    else:
        print "dots is ok"
        return 0 
# if domain contain Suspicious contents
def suspicious(url):
    st = url
    if "@" in url or "-" in url:
        print "suspicious link is not ok"
        return 1
    else:
        print "suspicious ok"
        return 0    
# Final calculation of weight
def url_feature(url):
    f1 = domain_age(url)
    f2 = length_url(url)
    f3 = ipcheck(url)
    f4 = dotUrl(url)
    f5 = suspicious(url)
    weight = (f1 + f2 + f3 + f4 + f5)
    return weight
'''    
infile = open("mainfile.txt", "r")
outfile = open("testedfile_1.txt", "w")
for line in infile:
    line1 = line.split(",")
    url = url_feature(line1[2])
    print url
    if url >= 1:
        outfile.write(line1[0]+","+"1"+","+line1[2])
    else:
        outfile.write(line1[0]+","+"0"+","+line1[2])        

url = "https://www.google.com"    
url= url_feature(url)
print url
'''
