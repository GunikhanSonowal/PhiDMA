from google import search
import urllib2
from tf1 import tfmain
from lcs1 import lcsMain
from editDistance import editDistance
import os
import sys
import re
import urllib
from bs4 import BeautifulSoup
import ssl
import requests
from tld import get_tld
#inlist = open("totallink.txt", "w")
#terms = open("temp.txt", "r")
def urlMatch(line):
    try:
        print "url open file"
        html = urllib2.urlopen(line).read()
        
        soup = BeautifulSoup(html, "lxml")

        # kill all script and style elements
        for script in soup(["script", "style"]):
            script.extract()    # rip it out

        # get text
        text = soup.get_text()

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())
        # break multi-headlines into a line each
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)
        text = text.encode('ascii', 'ignore')
        web = open("webfile.html", "w")

        web.write(str(text))

        
        web.write("url:"+line+"\n") # add the url to source code
        web.close()
        tfmain("webfile.html", line) # find the tf of the webpage
        
        print "urlib close file"
    except Exception, e:
        print "url exception",e
            
    inlist = open("totallink.txt", "w") # open the file where we have to save the link
    terms = open("tf.txt" , "r") # terms save file
    try:
        domain = terms.readline()
        print "search item", domain
        for url in search(domain, stop=30): # search in google  
            inlist.write(url+"\n") # write the link in totallink.txt
        inlist.close()
        if os.stat("totallink.txt").st_size == 0: # return any link or not
            print "file is empty! phishing site"
            sys.exit(1)
    except Exception, e:
        print "google exception",e           
        
             
    
    

    


