import requests
from bs4 import BeautifulSoup
import re
def accessibility(line):
    try:
        print "\n accessibility checking start"
        fp=open('stringmatch.txt','r')
        urls = fp.read().split('\n')[:-1]
        def extract_result(html):
	        soup = BeautifulSoup(html,"lxml")
	        result = soup.find('span', {'style': 'color:red'}).get_text()
	        return result
        base_url= "http://achecker.ca/checkacc.php?"
        ff=open('guni.txt','w',)
        final = open("main_result.txt", "w")
        payload={"uri":line,"id":"ca44c777a5bb9383f652f734f813320baea54aa2","guide":"WCAG2-AA","output":"html","offset" : 0}
        r= requests.get(base_url, params=payload.items())
        print r.status_code
        if r.status_code == requests.codes.ok:
		    output= ''.join(e for e in line if e.isalnum())
		    st = extract_result(r.text).encode('utf-8')
		    final.write(extract_result(r.text).encode('utf-8')+"\n")
		    print extract_result(r.text)
        else:
		        print "No data",line,r.status_code
        fb=open(output+".html",'w')
	        #fb.write(r.text)
        fb.close()
        ff.close()
    except Exception, e:
        print "PHishing site:", e
                               
