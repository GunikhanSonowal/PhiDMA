import sys
li = open("whitelist.txt", "r")
def list(line):
    for white in li:
        if line in white:
            
            return 1
            sys.exit(1)
    return 0            
             
