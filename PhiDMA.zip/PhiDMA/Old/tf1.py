import re
import string

frequency = {}
def tfmain(line, url):
    document_text = open(line, 'r')
    text_string = document_text.read().lower()
    match_pattern = re.findall(r'\b[a-z]{3,15}\b', text_string)

    for word in match_pattern:
        count = frequency.get(word,0)
        frequency[word] = count + 1
    i = 0  
    infile = open("tf.txt", "w")  
    #frequency_list = frequency.keys()
    for key, value in sorted(frequency.iteritems(), key=lambda (k,v): (v,k), reverse=True):
        
        if i <= 5:
            
            if value > 1:
                infile.write(key+", ")
                
                print key, value
                i = i +1
    infile.write(url)
    infile.close()         

