prev = None
infile = open("mainfile1.txt","w")
for line in sorted(open('mainfile.txt',"r")):
        line = line.strip()
        if prev is not None and not line.startswith(prev):
            infile.write(prev+"\n")
        prev = line
if prev is not None:
        infile.write(prev+"\n")         
            
