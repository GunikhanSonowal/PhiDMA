from pyxdameraulevenshtein import damerau_levenshtein_distance, normalized_damerau_levenshtein_distance
from lcs import lcs
def editDistance(str1, str2):
        result = normalized_damerau_levenshtein_distance(str1, str2)  
        result = result * 100  
        return result
st = "guni"
st1 = "guni1"        
print "edit distance", editDistance(st, st1)
print "lcs is ", lcs(st, st1, len(st), len(st1))        
