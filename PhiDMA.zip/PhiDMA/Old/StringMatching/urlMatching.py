from google import search
from editDistance import editDistance
from lcs import lcs
inlist = open("totallink.txt", "w")
st = raw_input("Enter the terms\n")
for url in search(st, stop=30):
    print(url)     
    inlist.write(url+"\n")
inlist.close()
    

    


