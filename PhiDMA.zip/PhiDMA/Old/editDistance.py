from pyxdameraulevenshtein import damerau_levenshtein_distance, normalized_damerau_levenshtein_distance
def editDistance(str1, str2):
        result = normalized_damerau_levenshtein_distance(str1, str2)  
        result = (1-result) * 100  
        return result
infile = open("mainfile.txt", "r")
url = "http://google.com"
count = 0
for line in infile:
    line1 = line.split(",")
    result = editDistance(url, line1[2])
    if result > 81:
        count = count + 1
        #print line1[2]
       
