
from bs4 import BeautifulSoup
import re

html= open('/home/ajit/work/achecker/result/httpinternetseguroeletronicopehu.html','r').read()

soup = BeautifulSoup(html,"lxml")
result = soup.find('span', {'style': 'color:red'}).get_text()
print(result)
#result = soup.find('span', {'style': 'color:red'}).contents
#print result.contents



