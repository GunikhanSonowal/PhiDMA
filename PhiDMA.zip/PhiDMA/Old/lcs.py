def lcs(X, Y, m, n):

	if m == 0 or n == 0:
	    print "lcs main1"
	    return 0 
	    
	elif X[m-1] == Y[n-1]:
	    print "lcs main2", 1 + lcs(X, Y, m-1, n-1)
	    return 1 + lcs(X, Y, m-1, n-1)
	else:
	    print "lcs main3", 1 + lcs(X, Y, m-1, n-1)
	    return max(lcs(X, Y, m, n-1), lcs(X, Y, m-1, n))
def lcsMain(a, b):	    
    print a, type(a)
    print b, type(b)
    a_len = len(a)
    b_len = len(b)
    print "length a", a_len
    print "length b", b_len
    st = lcs(a, b, a_len, b_len)
    print "gunikhan sonowal", st
    print st
    if a_len == b_len:
        print "lcs result", (float(st) / a_len)*100
        return (float(st) / a_len)*100
    else:
        if a_len > b_len:
            print "lcs result", (float(st) / a_len)*100
            return (float(st) / a_len)*100
        else:
            print "lcs result", (float(st) / b_len)*100
            return (float(st) / b_len)*100    
url = "http://google.com"
urls = "http://google.ca"
result = lcsMain(url, urls)
print result
