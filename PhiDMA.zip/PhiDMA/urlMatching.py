###############################################
############ Lexical Signature #################
################################################
import urllib2
import os
import sys
import re
from bs4 import BeautifulSoup
from tld import get_tld
def urlMatch(line):
    try:
        html = urllib2.urlopen(line).read()        
        soup = BeautifulSoup(html, "lxml")        
        for script in soup(["script", "style"]):# kill all script and style elements
            script.extract()    # rip it out        
        text = soup.get_text()# get text        
        lines = (line.strip() for line in text.splitlines())# break into lines and remove leading and trailing space on each       
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))# break multi-headlines into a line each        
        text = '\n'.join(chunk for chunk in chunks if chunk)# drop blank lines
        text = text.encode('ascii', 'ignore')
        web = open("webfile.txt", "w")
        web.write("url:"+line+"\n") # add the url to source code        
        web.write(str(text))              
    except Exception, e:
        print "url exception",e 
        return False       
    web.close()
               

