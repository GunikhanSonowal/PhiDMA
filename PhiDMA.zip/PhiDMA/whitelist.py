#########################################
############## Whitelist Filter #########
########################################
def CheckInWhiteList(url):
    fp = open("whitelist.txt", "r")
    whitelist = [url.strip() for url in fp.readlines()]
    return url in whitelist

if __name__ == "__main__":
	urls = ["www.google.com","http://www.google.com","www.xyz.com","http://www.facebook.com"]
	for url in urls: 
    		print url,          
    		print CheckInWhiteList(url)
