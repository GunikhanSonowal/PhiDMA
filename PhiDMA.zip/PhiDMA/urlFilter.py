############################################
################ URL Feature filter
#############################################
from urlparse import urlparse
import tldextract
import sys
from datetime import datetime
import socket
from tld import get_tld
from ipwhois import IPWhois
from pprint import pprint
import re
# Domain age
def validate_ip(s):
    a = s.split('.')
    if len(a) != 4:
        return False
    for x in a:
        if not x.isdigit():
            return False
        i = int(x)
        if i < 0 or i > 255:
            return False
    return True
def domain_age(url):
    try:
        domain = get_tld(url)
        ipadress = socket.gethostbyname(domain)
        obj = IPWhois(ipadress)
        results = obj.lookup_rdap(depth=1)
        st = results['asn_date']
        b_date = datetime.strptime(st, '%Y-%m-%d')
        #print "Age : %d" % ((datetime.today() - b_date).days/365)
        if (datetime.today() - b_date).days/365 > 1:
            #print "age is ok"
            return 0
        else:
            #print "age is not ok"
            return 1    
    except Exception,e:
        #print "age is undefine"
        return 0 # explain in paper    
        
# Length of the url        
def length_url(url):
    ext = tldextract.extract(url)
    ext.domain
    st = ext.domain
    l = len(st)
    if l > 53:
        #print "length not ok"
        return 1
    else:
        #print "length is ok"
        return 0    
# Domain contain IP    
def ipcheck(url):
    ext = tldextract.extract(url)
    ext.domain
    st = ext.domain
    if validate_ip(st) == True :
        #print "ip is ok"
        return 1
    else:
        
        #print "ip is not ok"
        return 0    
# Number of dots
def dotUrl(url):
    parsed = urlparse(url)
    st = parsed.netloc 
    count = 0
    print st
    for line in st:
        if line == ".":
            count = count + 1
    print "no of dots", count        
    if count >= 3:
        #print "dots is no ok"
        return 1
    else:
        #print "dots is ok"
        return 0 
# if domain contain Suspicious contents
def suspicious(url):
    st = url
    if "@" in url or "-" in url:
        #print "suspicious link is not ok"
        return 1
    else:
        #print "suspicious ok"
        return 0    
# Final calculation of weight
def url_score(url):
    f1 = domain_age(url)
    f2 = length_url(url)
    f3 = ipcheck(url)
    f4 = dotUrl(url)
    f5 = suspicious(url)  
    print "domain_age:", f1, "length_Url:", f2, "ipcheck:", f3, "dot_url:", f4, "suspicious:", f5  
    return (f1 + f2 + f3 + f4 + f5)
if __name__== "__main__":   
    infile = open("inputurls2.txt", "r")
    outfile = open("testedfile_1.1.txt", "w")
    for line in infile:
        line1 = line.split(",")
        url = url_score(line1[2])
        print url
        if url >= 1:
            outfile.write(line1[0]+","+"1"+","+line1[2])
        else:
            outfile.write(line1[0]+","+"0"+","+line1[2])        

