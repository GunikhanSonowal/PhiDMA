import duckduckgo
import sys
import os
def duckduckgoSearch():
        print "\t Duck Duck Go seach Start"
        inlist = open("totallink.txt", "w") # open the file where we have to save the link
        terms = open("tf.txt" , "r") # terms save file
        try:
            domain = terms.readline()
            print "search item", domain
            for link in duckduckgo.search(domain, max_results=30): # search in google
                #print link  
                inlist.write(link+"\n") # write the link in totallink.txt              
            inlist.close()
            terms.close()
        except Exception, e:
            print "Duck Duck Go exception", e
        
if __name__ == "__main__":
    duckduckgoSearch()                  

