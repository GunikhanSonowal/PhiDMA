###########################################
######## Longest common Subsequence 
##################################
def lcs(S,T):
    m = len(S)
    n = len(T)
    counter = [[0]*(n+1) for x in range(m+1)]
    longest = 0
    lcs_set = set()
    for i in range(m):
        for j in range(n):
            if S[i] == T[j]:
                c = counter[i][j] + 1
                counter[i+1][j+1] = c
                if c > longest:
                    lcs_set = set()
                    longest = c
                    lcs_set.add(S[i-c+1:i+1])
                elif c == longest:
                    lcs_set.add(S[i-c+1:i+1])

    return lcs_set

# test 1
def lcsMain(str1, str2):
    ret = lcs(str1, str2)
    a_len = len(str1)
    b_len = len(str2)
    st = 0
    for s in ret:
        #print len(s)
        st = len(s)
    if a_len == b_len:
            #print "lcs result", (float(st) / a_len)*100
            return (float(st) / a_len)*100
    else:
            if a_len > b_len:
                #print "lcs result", (float(st) / a_len)*100
                return (float(st) / a_len)*100
            else:
                #print "lcs result", (float(st) / b_len)*100
                return (float(st) / b_len)*100
   
infile = open("mainfile.txt", "r")
url = "http://google.com"
count = 0
for line in infile:
    line1 = line.split(",")
    result = lcsMain(url, line1[2])
    if result > 83:
        count = count + 1
        #print line1[2]

