
chrome.browserAction.onClicked.addListener(function(tab) {
 
  chrome.tabs.executeScript({
    file: "/content_scripts/phidma.js"
  });
});

chrome.commands.onCommand.addListener(function(command) {
chrome.tabs.executeScript({
    file: "/content_scripts/phidma.js"
  });
});
