from flask import Flask, render_template, request, url_for,redirect
from PhidMA import phidMA
#####################################################################################################
app = Flask(__name__)
def ourProgram(domain):
    return phidMA(domain)    

@app.route('/', methods=['POST'])
def download():
        url = request.form['content']
        check = ourProgram(url)
        return check
        
if __name__ == '__main__':
  app.run(debug=True)

