######################################################
#################### Confusion Matrix & Accuracy 
######################################################
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score
import matplotlib.pyplot as plt
# import pandas as pd
# import csv
filename = "Result_final.csv"
file1 = open(filename, "r")
# reader = csv.reader(filename)
# df = pd.read_csv(filename)
# data = df.values
y_test = []
y_pred = []
for line in file1:
    line = line.split(",")
    y_test.append(line[1])
    y_pred.append(line[2])
matrix = confusion_matrix(y_test, y_pred)
print accuracy_score(y_test, y_pred)
plt.matshow(matrix)
plt.title('Confusion Matrix')
plt.colorbar()
plt.ylabel("True label")
plt.xlabel("Predicted label")
plt.show()
