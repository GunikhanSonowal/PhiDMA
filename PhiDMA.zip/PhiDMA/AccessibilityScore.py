import requests
from bs4 import BeautifulSoup
import re
import csv
from itertools import islice
from StandardDeviation import standardDeviation
import codecs


def extract_result(html):
    soup = BeautifulSoup(html,"lxml")
    result = soup.find('span', {'style': 'color:red'}).get_text()
    return result

def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())
def writeToCSV(data):
    print "No use this function"    
    
def accessibility():
    try:
        base_url= "http://achecker.ca/checkacc.php?" 
        mycsvfile = open('mydata.csv', 'w')      
        thedatawriter = csv.writer(mycsvfile)
        thedatawriter.writerow(["Errors", "Likeyly Errors", "Potential Errors"])
        print "\n accessibility checking start"
        fp=open('googleSimilarUrls.txt', 'r')
        
        urls = fp.read().split('\n')[:-1]
        fp.close()               
        for url in urls:
            payload={"uri":url,"id":"ca44c777a5bb9383f652f734f813320baea54aa2","guide":"WCAG2 AA","output":"html","offset" : 0}
            r= requests.get(base_url, params=payload.items())
            dataentry = {}
            if r.status_code == requests.codes.ok:		        
		        data = extract_result(r.text)
		        result = re.findall('\d+|\D+', data) # string start with number
		        result = [item.strip() for item in result]                
		        result.reverse() # string with string                
		        dataentry = dict(list(chunk(result, 2)))                
		        print dataentry
		        thedatawriter.writerow([dataentry.get('Errors', 0), dataentry.get('Likely Problems', 0), dataentry.get('Potential Problems', 0)])
            else:
		       print "No data",url,r.status_code 
		       return False
        mycsvfile.close()
    except Exception, e:
        print "Phishing site:", e
        return False
     
def mainAccessibleFunction():
    if accessibility() == False:
        return False    
if __name__ == "__main__": mainAccessibleFunction()                       
