#######################################
########### String Matching Filter 
########################################
from lcs import lcsMain
from editDistance import editDistance
 
import sys
def checkUrlMatch(iUrl): 
    temp = 0
    inlist = open("totallink.txt", "r") # open the total link
    fp = open("googleSimilarUrls.txt", "w")
    print "\t String matching with duck duck go link"
    fp.write(iUrl)   
    for gUrl in inlist:
        #print "origianl matching",iUrl, gUrl
        lcsScore = lcsMain(gUrl, iUrl)
        editScore = editDistance(gUrl, iUrl)
        print gUrl,"lec, edit",lcsScore,editScore
        if  lcsScore >=33 and editScore >= 62: # check the link with url
            print gUrl
            fp.write("\n"+gUrl)
            temp = 1
            break
    if temp == 1:
        fp.close()
        print "string matching pass\n"
        return True
    else:        
        fp.close()
        print "string matching fail\n"
        return False    
    inlist.close()   
if __name__=="__main__":
    checkUrlMatch("http://ask.com/")          
                   
     

        
