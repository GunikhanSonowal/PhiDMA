from lcs1 import lcsMain
from editDistance import editDistance
output = open("stringThreshold.txt", "w")
def matching(row, line):
        print row, line
        lcsScore = lcsMain(row, line)
        editScore = editDistance(row, line)
        if  lcsScore >=20 and editScore >= 20:
            output.write(str(lcsScore)+","+str(editScore)+","+row+"\n") 
def main():
    with open('inputurls.txt', 'r') as file1:
        with open('inputurls2.txt', 'r') as file2:
            for line, line2 in zip(file1, file2):
                line1 = line.split(",")
                line2 = line2.split(",")
                matching(line1[2], line2[2])   
if __name__=="__main__":
    main()            
