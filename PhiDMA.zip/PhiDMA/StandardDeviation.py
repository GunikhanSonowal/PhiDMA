##########################################
############## Standard Devaiation #############
###############################################
import numpy
import codecs
import csv

def standardDeviation():
    try:
        infile = open("mydata.csv", "r")
        print "Standard Deviation Start"
        std1 = std2 = std3 = 0
        list1, list2, list3 = ([] for i in range(3))
        reader = csv.reader(infile)
        next(reader)
        for row in reader:
            list1.append(int(row[0]))
            list2.append(int(row[1]))
            list3.append(int(row[2]))
        std1 = numpy.std(list1)
        std2 = numpy.std(list2) 
        std3 = numpy.std(list3)
        final = std1 + std2 + std3
        final_score = final/3
        return final_score
    except Exception, e:
        print e        
if __name__ == "__main__":
    standardDeviation()
